/*
 * Translations for de
 *
 * This file was autotomatically generated from de.po
 * DO NOT EDIT!
 */

Language = {
    "Connecting...": "Verbunden...",
    "Connected (encrypted) to ": "Verbunden mit (verschlüsselt) ",
    "Connected (unencrypted) to ": "Verbunden mit (unverschlüsselt) ",
    "Disconnecting...": "Verbindung trennen...",
    "Disconnected": "Verbindung zum Server getrennt",
    "Must set host and port": "Richten Sie Host und Port ein",
    "Password is required": "Passwort ist erforderlich",
    "Forcing clipping mode since scrollbars aren't supported by IE in fullscreen": "'Clipping-Modus' aktiviert, Scrollbalken in 'IE-Vollbildmodus' werden nicht unterstützt",
    "Disconnect timeout": "Timeout beim trennen",
};
